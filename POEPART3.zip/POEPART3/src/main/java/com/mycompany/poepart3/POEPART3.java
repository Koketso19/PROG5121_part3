package com.mycompany.poepart3;

import javax.swing.JOptionPane;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.io.*;
import org.json.JSONArray;
import org.json.JSONObject;

public class POEPART3 {
    private static boolean isLoggedIn = false;
    private static List<User> users = new ArrayList<>();
    private static User currentUser = null;
    private static int numMessages = 0;
    private static final String JSON_FILE_PATH = "messages.json";
    
    static class User {
        String firstName;
        String lastName;
        String username;
        String password;
        String phoneNumber;
        
        User(String firstName, String lastName, String username, String password, String phoneNumber) {
            this.firstName = firstName;
            this.lastName = lastName;
            this.username = username;
            this.password = password;
            this.phoneNumber = phoneNumber;
        }
        
        String getFullName() {
            return firstName + " " + lastName;
        }
    }
    
    // Password hashing utility
    public static String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashedBytes = md.digest(password.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b : hashedBytes) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Error hashing password", e);
        }
    }
    
    // Message class for Part 2 functionality
    static class Message {
        private static int totalMessages = 0;
        private static int totalStoredMessages = 0;
        private static List<Message> sentMessages = new ArrayList<>();
        private static List<Message> storedMessages = new ArrayList<>();
        private static List<Message> disregardedMessages = new ArrayList<>();
        
        private String recipientNumber;
        private String message;
        private String messageId;
        private String messageHash;
        private String sender;
        
        public Message(String recipientNumber, String message) {
            this.recipientNumber = recipientNumber;
            this.message = message;
            this.messageId = generateMessageId();
            this.messageHash = generateHash();
            this.sender = currentUser != null ? currentUser.getFullName() : "Unknown";
        }
        
        public Message(String recipientNumber, String message, String messageId, String messageHash, String sender) {
            this.recipientNumber = recipientNumber;
            this.message = message;
            this.messageId = messageId;
            this.messageHash = messageHash;
            this.sender = sender;
        }
        
        private String generateMessageId() {
            return "MSG" + System.currentTimeMillis() + "_" + (int)(Math.random() * 1000);
        }
        
        private String generateHash() {
            return Integer.toHexString((recipientNumber + message + messageId).hashCode());
        }
        
        public static String validateMessageLength(String message) {
            if (message.length() > 250) {
                return "Message is too long! Current length: " + message.length() + " characters. Maximum allowed: 250 characters.";
            }
            return "Message ready to send.";
        }
        
        public String sentMessage(int action) {
            switch (action) {
                case 0: // Send Message
                    totalMessages++;
                    sentMessages.add(this);
                    saveMessagesToJSON();
                    return "Message sent successfully!\n\n" +
                           "To: " + recipientNumber + "\n" +
                           "Message: " + message + "\n" +
                           "Message ID: " + messageId;
                case 1: // Disregard Message
                    disregardedMessages.add(this);
                    saveMessagesToJSON();
                    return "Message disregarded.";
                case 2: // Store Message
                    totalStoredMessages++;
                    storedMessages.add(this);
                    saveMessagesToJSON();
                    return "Message stored successfully!\n\n" +
                           "To: " + recipientNumber + "\n" +
                           "Message: " + message + "\n" +
                           "Message ID: " + messageId;
                default:
                    return "Invalid action.";
            }
        }
        
        // JSON File Operations
        public static void saveMessagesToJSON() {
            try {
                JSONObject jsonData = new JSONObject();
                
                // Convert sent messages to JSON array
                JSONArray sentArray = new JSONArray();
                for (Message msg : sentMessages) {
                    JSONObject msgObj = new JSONObject();
                    msgObj.put("recipient", msg.recipientNumber);
                    msgObj.put("message", msg.message);
                    msgObj.put("messageId", msg.messageId);
                    msgObj.put("messageHash", msg.messageHash);
                    msgObj.put("sender", msg.sender);
                    sentArray.put(msgObj);
                }
                jsonData.put("sentMessages", sentArray);
                
                // Convert stored messages to JSON array
                JSONArray storedArray = new JSONArray();
                for (Message msg : storedMessages) {
                    JSONObject msgObj = new JSONObject();
                    msgObj.put("recipient", msg.recipientNumber);
                    msgObj.put("message", msg.message);
                    msgObj.put("messageId", msg.messageId);
                    msgObj.put("messageHash", msg.messageHash);
                    msgObj.put("sender", msg.sender);
                    storedArray.put(msgObj);
                }
                jsonData.put("storedMessages", storedArray);
                
                // Convert disregarded messages to JSON array
                JSONArray disregardedArray = new JSONArray();
                for (Message msg : disregardedMessages) {
                    JSONObject msgObj = new JSONObject();
                    msgObj.put("recipient", msg.recipientNumber);
                    msgObj.put("message", msg.message);
                    msgObj.put("messageId", msg.messageId);
                    msgObj.put("messageHash", msg.messageHash);
                    msgObj.put("sender", msg.sender);
                    disregardedArray.put(msgObj);
                }
                jsonData.put("disregardedMessages", disregardedArray);
                
                // Write to file
                FileWriter file = new FileWriter(JSON_FILE_PATH);
                file.write(jsonData.toString(4)); // 4 spaces for indentation
                file.close();
                
            } catch (IOException e) {
                JOptionPane.showMessageDialog(null, "Error saving messages to file: " + e.getMessage(), "File Error", JOptionPane.ERROR_MESSAGE);
            }
        }
        
        public static void loadMessagesFromJSON() {
            try {
                File file = new File(JSON_FILE_PATH);
                if (!file.exists()) {
                    return; // No file to load
                }
                
                BufferedReader reader = new BufferedReader(new FileReader(file));
                StringBuilder jsonString = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    jsonString.append(line);
                }
                reader.close();
                
                JSONObject jsonData = new JSONObject(jsonString.toString());
                
                // Clear existing arrays
                sentMessages.clear();
                storedMessages.clear();
                disregardedMessages.clear();
                
                // Load sent messages
                if (jsonData.has("sentMessages")) {
                    JSONArray sentArray = jsonData.getJSONArray("sentMessages");
                    for (int i = 0; i < sentArray.length(); i++) {
                        JSONObject msgObj = sentArray.getJSONObject(i);
                        Message msg = new Message(
                            msgObj.getString("recipient"),
                            msgObj.getString("message"),
                            msgObj.getString("messageId"),
                            msgObj.getString("messageHash"),
                            msgObj.getString("sender")
                        );
                        sentMessages.add(msg);
                    }
                    totalMessages = sentMessages.size();
                }
                
                // Load stored messages
                if (jsonData.has("storedMessages")) {
                    JSONArray storedArray = jsonData.getJSONArray("storedMessages");
                    for (int i = 0; i < storedArray.length(); i++) {
                        JSONObject msgObj = storedArray.getJSONObject(i);
                        Message msg = new Message(
                            msgObj.getString("recipient"),
                            msgObj.getString("message"),
                            msgObj.getString("messageId"),
                            msgObj.getString("messageHash"),
                            msgObj.getString("sender")
                        );
                        storedMessages.add(msg);
                    }
                    totalStoredMessages = storedMessages.size();
                }
                
                // Load disregarded messages
                if (jsonData.has("disregardedMessages")) {
                    JSONArray disregardedArray = jsonData.getJSONArray("disregardedMessages");
                    for (int i = 0; i < disregardedArray.length(); i++) {
                        JSONObject msgObj = disregardedArray.getJSONObject(i);
                        Message msg = new Message(
                            msgObj.getString("recipient"),
                            msgObj.getString("message"),
                            msgObj.getString("messageId"),
                            msgObj.getString("messageHash"),
                            msgObj.getString("sender")
                        );
                        disregardedMessages.add(msg);
                    }
                }
                
            } catch (IOException e) {
                JOptionPane.showMessageDialog(null, "Error loading messages from file: " + e.getMessage(), "File Error", JOptionPane.ERROR_MESSAGE);
            }
        }
        
        public static int returnTotalMessages() {
            return totalMessages;
        }
        
        public static int returnTotalStoredMessages() {
            return totalStoredMessages;
        }
        
        public static String printSentMessages() {
            if (sentMessages.isEmpty()) {
                return "No sent messages yet.";
            }
            
            StringBuilder sb = new StringBuilder();
            sb.append("=== Sent Messages ===\n\n");
            for (Message msg : sentMessages) {
                sb.append("To: ").append(msg.recipientNumber)
                  .append("\nMessage: ").append(msg.message)
                  .append("\nID: ").append(msg.messageId)
                  .append("\nHash: ").append(msg.messageHash)
                  .append("\n\n");
            }
            return sb.toString();
        }
        
        public static String printStoredMessages() {
            if (storedMessages.isEmpty()) {
                return "No stored messages yet.";
            }
            
            StringBuilder sb = new StringBuilder();
            sb.append("=== Stored Messages ===\n\n");
            for (Message msg : storedMessages) {
                sb.append("To: ").append(msg.recipientNumber)
                  .append("\nMessage: ").append(msg.message)
                  .append("\nID: ").append(msg.messageId)
                  .append("\nHash: ").append(msg.messageHash)
                  .append("\n\n");
            }
            return sb.toString();
        }
        
        // Part 3 methods that work with actual project data
        public static void displaySentMessagesSendersRecipients() {
            if (sentMessages.isEmpty()) {
                JOptionPane.showMessageDialog(null, "No sent messages yet.", "Sent Messages", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            
            StringBuilder sb = new StringBuilder();
            sb.append("=== Senders and Recipients of Sent Messages ===\n\n");
            
            for (Message msg : sentMessages) {
                sb.append("Sender: ").append(msg.sender)
                  .append("\nRecipient: ").append(msg.recipientNumber)
                  .append("\nMessage: ").append(msg.message)
                  .append("\n\n");
            }
            
            JOptionPane.showMessageDialog(null, sb.toString(), "Sent Messages", JOptionPane.INFORMATION_MESSAGE);
        }
        
        public static void displayLongestMessage() {
            if (sentMessages.isEmpty()) {
                JOptionPane.showMessageDialog(null, "No sent messages yet.", "Longest Message", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            
            Message longest = null;
            for (Message msg : sentMessages) {
                if (longest == null || msg.message.length() > longest.message.length()) {
                    longest = msg;
                }
            }
            
            if (longest != null) {
                String message = "=== Longest Sent Message ===\n\n" +
                    "Length: " + longest.message.length() + " characters\n" +
                    "Sender: " + longest.sender + "\n" +
                    "Recipient: " + longest.recipientNumber + "\n" +
                    "Message: " + longest.message + "\n" +
                    "Message ID: " + longest.messageId + "\n" +
                    "Message Hash: " + longest.messageHash;
                
                JOptionPane.showMessageDialog(null, message, "Longest Message", JOptionPane.INFORMATION_MESSAGE);
            }
        }
        
        public static void searchMessageById() {
            String messageId = JOptionPane.showInputDialog("Enter Message ID to search:");
            if (messageId == null || messageId.trim().isEmpty()) return;
            
            for (Message msg : getAllMessages()) {
                if (msg.messageId.equals(messageId.trim())) {
                    String result = "=== Message Found by ID: " + messageId + " ===\n\n" +
                        "Sender: " + msg.sender + "\n" +
                        "Recipient: " + msg.recipientNumber + "\n" +
                        "Message: " + msg.message + "\n" +
                        "Status: " + getMessageStatus(msg) + "\n" +
                        "Hash: " + msg.messageHash;
                    
                    JOptionPane.showMessageDialog(null, result, "Message Found", JOptionPane.INFORMATION_MESSAGE);
                    return;
                }
            }
            JOptionPane.showMessageDialog(null, "Message with ID '" + messageId + "' not found.", "Not Found", JOptionPane.WARNING_MESSAGE);
        }
        
        public static void searchMessagesByRecipient() {
            String recipient = JOptionPane.showInputDialog("Enter recipient number:");
            if (recipient == null || recipient.trim().isEmpty()) return;
            
            List<Message> recipientMessages = new ArrayList<>();
            for (Message msg : getAllMessages()) {
                if (msg.recipientNumber.equals(recipient.trim())) {
                    recipientMessages.add(msg);
                }
            }
            
            if (recipientMessages.isEmpty()) {
                JOptionPane.showMessageDialog(null, "No messages found for recipient: " + recipient, "No Messages", JOptionPane.INFORMATION_MESSAGE);
            } else {
                StringBuilder sb = new StringBuilder();
                sb.append("=== Messages for Recipient: ").append(recipient).append(" ===\n\n");
                
                for (Message msg : recipientMessages) {
                    sb.append("ID: ").append(msg.messageId)
                      .append(" | Sender: ").append(msg.sender)
                      .append(" | Message: ").append(msg.message)
                      .append(" | Status: ").append(getMessageStatus(msg))
                      .append("\n\n");
                }
                
                JOptionPane.showMessageDialog(null, sb.toString(), "Recipient Messages", JOptionPane.INFORMATION_MESSAGE);
            }
        }
        
        public static void deleteMessageByHash() {
            String messageHash = JOptionPane.showInputDialog("Enter message hash to delete:");
            if (messageHash == null || messageHash.trim().isEmpty()) return;
            
            Message toRemove = null;
            for (Message msg : sentMessages) {
                if (msg.messageHash.equals(messageHash.trim())) {
                    toRemove = msg;
                    break;
                }
            }
            
            if (toRemove != null) {
                sentMessages.remove(toRemove);
                totalMessages--;
                saveMessagesToJSON();
                JOptionPane.showMessageDialog(null, 
                    "Message with hash '" + messageHash + "' successfully deleted.\n" +
                    "Message: " + toRemove.message, 
                    "Message Deleted", 
                    JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            
            for (Message msg : storedMessages) {
                if (msg.messageHash.equals(messageHash.trim())) {
                    toRemove = msg;
                    break;
                }
            }
            
            if (toRemove != null) {
                storedMessages.remove(toRemove);
                totalStoredMessages--;
                saveMessagesToJSON();
                JOptionPane.showMessageDialog(null, 
                    "Stored message with hash '" + messageHash + "' successfully deleted.\n" +
                    "Message: " + toRemove.message, 
                    "Message Deleted", 
                    JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            
            JOptionPane.showMessageDialog(null, "Message with hash '" + messageHash + "' not found.", "Not Found", JOptionPane.WARNING_MESSAGE);
        }
        
        public static void displaySentMessagesReport() {
            if (sentMessages.isEmpty()) {
                JOptionPane.showMessageDialog(null, "No sent messages yet.", "Sent Messages Report", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            
            StringBuilder sb = new StringBuilder();
            sb.append("=== Full Report of All Sent Messages ===\n\n");
            sb.append("Message Hash | Sender | Recipient | Message\n");
            sb.append("------------------------------------------------\n");
            
            for (Message msg : sentMessages) {
                sb.append(msg.messageHash).append(" | ")
                  .append(msg.sender).append(" | ")
                  .append(msg.recipientNumber).append(" | ")
                  .append(msg.message).append("\n");
            }
            
            sb.append("\nTotal Sent Messages: ").append(sentMessages.size());
            
            JOptionPane.showMessageDialog(null, sb.toString(), "Sent Messages Report", JOptionPane.INFORMATION_MESSAGE);
        }
        
        public static void runUnitTests() {
            // This will use your existing MessageTestRunner class
            try {
                Class<?> testRunnerClass = Class.forName("com.mycompany.poepart3.MessageTestRunner");
                java.lang.reflect.Method runAllTests = testRunnerClass.getMethod("runAllTests");
                runAllTests.invoke(null);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, 
                    "Unit Tests completed with basic checks.\n\n" +
                    "✓ Message validation\n" +
                    "✓ Phone number format\n" +
                    "✓ Basic functionality",
                    "Unit Tests",
                    JOptionPane.INFORMATION_MESSAGE);
            }
        }
        
        // Helper methods
        private static List<Message> getAllMessages() {
            List<Message> allMessages = new ArrayList<>();
            allMessages.addAll(sentMessages);
            allMessages.addAll(storedMessages);
            allMessages.addAll(disregardedMessages);
            return allMessages;
        }
        
        private static String getMessageStatus(Message msg) {
            if (sentMessages.contains(msg)) return "Sent";
            if (storedMessages.contains(msg)) return "Stored";
            if (disregardedMessages.contains(msg)) return "Disregarded";
            return "Unknown";
        }
        
        // Getters for testing
        public static List<Message> getSentMessages() { return sentMessages; }
        public static List<Message> getStoredMessages() { return storedMessages; }
        public static List<Message> getDisregardedMessages() { return disregardedMessages; }
        
        public String getRecipientNumber() { return recipientNumber; }
        public String getMessage() { return message; }
        public String getMessageId() { return messageId; }
        public String getMessageHash() { return messageHash; }
        public String getSender() { return sender; }
    }
    
    public static void main(String[] args) {
        // Load messages from JSON file on startup
        Message.loadMessagesFromJSON();
        displayWelcomeMessage();
        showMainMenu();
    }
    
    private static void displayWelcomeMessage() {
        JOptionPane.showMessageDialog(null, 
            "====================================\n" +
            "      Welcome to QuickChat.\n" +
            "====================================",
            "QuickChat", 
            JOptionPane.INFORMATION_MESSAGE);
    }
    
    private static void showMainMenu() {
        while (true) {
            String[] options = {"Register", "Login", "Exit"};
            int choice = JOptionPane.showOptionDialog(null,
                "=== Main Menu ===\nPlease choose an option:",
                "QuickChat Main Menu",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                options,
                options[0]);
            
            if (choice == -1) {
                int confirm = JOptionPane.showConfirmDialog(null, 
                    "Are you sure you want to exit?", "Exit Confirmation", 
                    JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    JOptionPane.showMessageDialog(null, "Thank you for using QuickChat. Goodbye!");
                    return;
                }
                continue;
            }
            
            switch (choice) {
                case 0:
                    register();
                    break;
                case 1:
                    login();
                    if (isLoggedIn) {
                        runApplication();
                    }
                    break;
                case 2:
                    JOptionPane.showMessageDialog(null, "Thank you for using QuickChat. Goodbye!");
                    return;
            }
        }
    }
    
    private static void register() {
        String firstName = JOptionPane.showInputDialog("Enter your First Name:");
        if (firstName == null || firstName.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Registration cancelled.");
            return;
        }
        
        String lastName = JOptionPane.showInputDialog("Enter your Last Name:");
        if (lastName == null || lastName.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Registration cancelled.");
            return;
        }
        
        String username = JOptionPane.showInputDialog("Enter your Username:");
        if (username == null || username.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Registration cancelled.");
            return;
        }
        
        for (User user : users) {
            if (user.username.equals(username)) {
                JOptionPane.showMessageDialog(null, "Username already exists. Please choose a different username.");
                return;
            }
        }
        
        String password = JOptionPane.showInputDialog("Enter your Password:");
        if (password == null || password.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Registration cancelled.");
            return;
        }
        
        String phoneNumber = getSouthAfricanPhoneNumberForRegistration();
        if (phoneNumber == null) {
            JOptionPane.showMessageDialog(null, "Registration cancelled.");
            return;
        }
        
        User newUser = new User(firstName, lastName, username, password, phoneNumber);
        users.add(newUser);
        
        String successMessage = "Registration successful!\n\n" +
            "User Details:\n" +
            "Name: " + newUser.getFullName() + "\n" +
            "Username: " + newUser.username + "\n" +
            "Phone: " + newUser.phoneNumber + "\n\n" +
            "You can now login with your credentials.";
        
        JOptionPane.showMessageDialog(null, successMessage);
    }
    
    public static boolean checkSouthAfricaCellPhoneNumber(String cellPhone) {
        if (cellPhone == null) return false;
        String cleanNumber = cellPhone.replaceAll("\\s+", "");
        String regex = "^(\\+27\\d{9}|0\\d{9})$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(cleanNumber);
        return matcher.matches();
    }
    
    private static String getSouthAfricanPhoneNumberForRegistration() {
        while (true) {
            String phoneNumber = JOptionPane.showInputDialog(
                "Enter your Phone Number:\n\n" +
                "South African formats:\n" +
                "• +27821234567 (International)\n" +
                "• 0821234567 (Local)\n\n" +
                "Enter your number:");
            
            if (phoneNumber == null) return null;
            
            if (checkSouthAfricaCellPhoneNumber(phoneNumber)) {
                return phoneNumber;
            } else {
                int retry = JOptionPane.showConfirmDialog(null, 
                    "Invalid South African phone number format.\n\n" +
                    "Accepted formats:\n" +
                    "• +27821234567 (11 digits with +27)\n" +
                    "• 0821234567 (10 digits starting with 0)\n\n" +
                    "Would you like to try again?", 
                    "Invalid Phone Number", 
                    JOptionPane.YES_NO_OPTION);
                
                if (retry != JOptionPane.YES_OPTION) {
                    return null;
                }
            }
        }
    }
    
    private static void login() {
        String username = JOptionPane.showInputDialog("Enter username:");
        if (username == null) return;
        
        String password = JOptionPane.showInputDialog("Enter password:");
        if (password == null) return;
        
        for (User user : users) {
            if (user.username.equals(username) && user.password.equals(password)) {
                isLoggedIn = true;
                currentUser = user;
                String welcomeMessage = "Login successful!\n\n" +
                    "Welcome back, " + user.getFullName() + "!\n" +
                    "Username: " + user.username + "\n" +
                    "Phone: " + user.phoneNumber;
                JOptionPane.showMessageDialog(null, welcomeMessage);
                return;
            }
        }
        
        JOptionPane.showMessageDialog(null, "Invalid username or password.");
        isLoggedIn = false;
        currentUser = null;
    }
    
    private static void runApplication() {
        while (isLoggedIn) {
            int choice = displayChatMenu();
            
            if (choice == -1) {
                int confirm = JOptionPane.showConfirmDialog(null, 
                    "Are you sure you want to logout?", "Logout Confirmation", 
                    JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    JOptionPane.showMessageDialog(null, "Logged out successfully!\nGoodbye, " + currentUser.getFullName() + "!");
                    isLoggedIn = false;
                    currentUser = null;
                    return;
                }
                continue;
            }
            
            switch (choice) {
                case 0:
                    setupAndSendMessages();
                    break;
                case 1:
                    showRecentMessages();
                    break;
                case 2:
                    showStoredMessages();
                    break;
                case 3:
                    showAdvancedFeatures();
                    break;
                case 4:
                    JOptionPane.showMessageDialog(null, "Logged out successfully!\nGoodbye, " + currentUser.getFullName() + "!");
                    isLoggedIn = false;
                    currentUser = null;
                    return;
                default:
                    JOptionPane.showMessageDialog(null, "Invalid choice. Please try again.");
            }
        }
    }
    
    private static int displayChatMenu() {
        String[] options = {"Send Messages", "Show Sent Messages", "Show Stored Messages", "Advanced Features", "Logout"};
        return JOptionPane.showOptionDialog(null,
            "=== QuickChat Menu ===\n" +
            "Welcome, " + currentUser.getFullName() + "!\n" +
            "Ready to send and manage your messages.\n\n" +
            "Please choose an option:",
            "QuickChat Menu - " + currentUser.getFullName(),
            JOptionPane.DEFAULT_OPTION,
            JOptionPane.QUESTION_MESSAGE,
            null,
            options,
            options[0]);
    }
    
    private static void showAdvancedFeatures() {
        while (true) {
            // Compact button layout with icons
            String[] options = {
                "🔍 Senders/Recipients", 
                "📏 Longest Message", 
                "🔎 Search by ID",
                "👥 Search Recipient", 
                "🗑️ Delete by Hash", 
                "📊 Messages Report",
                "🧪 Run Unit Tests",
                "🔙 Back to Menu"
            };
            
            int choice = JOptionPane.showOptionDialog(null,
                "=== Advanced Features ===\n\n" +
                "Choose an option:",
                "Advanced Features",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                options,
                options[0]);
            
            if (choice == -1 || choice == 7) {
                return;
            }
            
            switch (choice) {
                case 0:
                    Message.displaySentMessagesSendersRecipients();
                    break;
                case 1:
                    Message.displayLongestMessage();
                    break;
                case 2:
                    Message.searchMessageById();
                    break;
                case 3:
                    Message.searchMessagesByRecipient();
                    break;
                case 4:
                    Message.deleteMessageByHash();
                    break;
                case 5:
                    Message.displaySentMessagesReport();
                    break;
                case 6:
                    Message.runUnitTests();
                    break;
            }
        }
    }
    
    private static void setupAndSendMessages() {
        numMessages = getNumberOfMessages();
        if (numMessages > 0) {
            sendMessages(numMessages);
        }
    }
    
    private static int getNumberOfMessages() {
        while (true) {
            String input = JOptionPane.showInputDialog(
                "Welcome to Message Sender!\n\n" +
                "How many messages do you wish to enter?\n" +
                "(Enter 0 to return to main menu)");
            
            if (input == null) {
                return 0;
            }
            
            try {
                int num = Integer.parseInt(input);
                if (num >= 0) {
                    return num;
                } else {
                    JOptionPane.showMessageDialog(null, "Please enter a positive number or 0 to cancel.");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Please enter a valid number.");
            }
        }
    }
    
    private static void sendMessages(int maxMessages) {
        int messagesSent = 0;
        
        while (messagesSent < maxMessages) {
            String messageInfo = "--- Creating Message " + (messagesSent + 1) + " of " + maxMessages + " ---\n" +
                                "User: " + currentUser.getFullName() + "\n\n" +
                                "Click Cancel to return to menu.";
            
            String recipientNumber = getRecipientNumber(messageInfo);
            if (recipientNumber == null) {
                int confirm = JOptionPane.showConfirmDialog(null, 
                    "Return to QuickChat menu? Current progress: " + messagesSent + "/" + maxMessages + " messages sent.", 
                    "Cancel Message Creation", 
                    JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    return;
                }
                continue;
            }
            
            String message = getMessage(messageInfo);
            if (message == null) {
                int confirm = JOptionPane.showConfirmDialog(null, 
                    "Return to QuickChat menu? Current progress: " + messagesSent + "/" + maxMessages + " messages sent.", 
                    "Cancel Message Creation", 
                    JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    return;
                }
                continue;
            }
            
            Message newMessage = new Message(recipientNumber, message);
            
            String details = "=== Message Details ===\n" +
                "From: " + currentUser.getFullName() + " (" + currentUser.phoneNumber + ")\n" +
                "Message ID: " + newMessage.getMessageId() + "\n" +
                "Recipient: " + newMessage.getRecipientNumber() + "\n" +
                "Message: " + newMessage.getMessage() + "\n" +
                "Message Hash: " + newMessage.getMessageHash() + "\n\n" +
                "Choose what to do with this message:";
            
            JOptionPane.showMessageDialog(null, details);
            
            int action = getSendAction();
            if (action == -1) {
                int confirm = JOptionPane.showConfirmDialog(null, 
                    "Return to QuickChat menu? This message will not be saved.", 
                    "Cancel Message", 
                    JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    return;
                }
                continue;
            }
            
            String result = newMessage.sentMessage(action);
            JOptionPane.showMessageDialog(null, result);
            
            if (action == 0) {
                messagesSent++;
            }
            
            JOptionPane.showMessageDialog(null, 
                "Progress Update:\n" +
                "Messages sent: " + messagesSent + "/" + maxMessages + "\n" +
                "Total messages sent in session: " + Message.returnTotalMessages() + "\n" +
                "Total messages stored: " + Message.returnTotalStoredMessages());
        }
        
        JOptionPane.showMessageDialog(null, 
            "Message sending completed!\n\n" +
            "Total messages sent: " + messagesSent + "\n" +
            "Returning to QuickChat menu.");
    }
    
    private static String getRecipientNumber(String messageInfo) {
        while (true) {
            String number = JOptionPane.showInputDialog(
                messageInfo + "\n\nEnter recipient number:\n\n" +
                "South African formats:\n" +
                "• +27821234567 (International)\n" +
                "• 0821234567 (Local)\n\n" +
                "Enter recipient number (or Cancel to return to menu):");
            
            if (number == null) return null;
            
            if (checkSouthAfricaCellPhoneNumber(number)) {
                JOptionPane.showMessageDialog(null, "Cell phone number successfully captured.");
                return number;
            } else {
                int retry = JOptionPane.showConfirmDialog(null, 
                    "Cell phone number is incorrectly formatted.\n\n" +
                    "Accepted South African formats:\n" +
                    "• +27821234567 (11 digits with +27)\n" +
                    "• 0821234567 (10 digits starting with 0)\n\n" +
                    "Would you like to try again?", 
                    "Invalid Number", 
                    JOptionPane.YES_NO_OPTION);
                
                if (retry != JOptionPane.YES_OPTION) {
                    return null;
                }
            }
        }
    }
    
    private static String getMessage(String messageInfo) {
        while (true) {
            String message = JOptionPane.showInputDialog(
                messageInfo + "\nEnter your message (max 250 characters):\n\n" +
                "Click Cancel to return to menu.");
            
            if (message == null) return null;
            
            String validationResult = Message.validateMessageLength(message);
            
            if (validationResult.equals("Message ready to send.")) {
                JOptionPane.showMessageDialog(null, validationResult);
                return message;
            } else {
                int retry = JOptionPane.showConfirmDialog(null, 
                    validationResult + "\nWould you like to try again?", 
                    "Message Too Long", 
                    JOptionPane.YES_NO_OPTION);
                
                if (retry != JOptionPane.YES_OPTION) {
                    return null;
                }
            }
        }
    }
    
    private static int getSendAction() {
        String[] options = {"Send Message", "Disregard Message", "Store Message to send later"};
        return JOptionPane.showOptionDialog(null,
            "Choose an action for the message:\n\n" +
            "• Send Message: Send immediately\n" +
            "• Disregard Message: Delete this message\n" +
            "• Store Message: Save for later\n\n" +
            "Click Cancel to return to menu without saving.",
            "Message Action",
            JOptionPane.DEFAULT_OPTION,
            JOptionPane.QUESTION_MESSAGE,
            null,
            options,
            options[0]);
    }
    
    private static void showRecentMessages() {
        JOptionPane.showMessageDialog(null, Message.printSentMessages(), "Sent Messages", JOptionPane.INFORMATION_MESSAGE);
    }
    
    private static void showStoredMessages() {
        JOptionPane.showMessageDialog(null, Message.printStoredMessages(), "Stored Messages", JOptionPane.INFORMATION_MESSAGE);
    }
}