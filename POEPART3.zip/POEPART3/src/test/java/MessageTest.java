package com.mycompany.poepart3;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.AfterEach;
import static org.junit.jupiter.api.Assertions.*;
import java.io.File;
import java.util.List;

public class MessageTest {
    
    @BeforeEach
    public void setUp() {
        // Clear any existing messages before each test
        POEPART3.Message.getSentMessages().clear();
        POEPART3.Message.getStoredMessages().clear();
        POEPART3.Message.getDisregardedMessages().clear();
    }
    
    @AfterEach
    public void tearDown() {
        // Clean up after tests
        File jsonFile = new File("messages.json");
        if (jsonFile.exists()) {
            jsonFile.delete();
        }
    }
    
    @Test
    public void testMessageValidation() {
        System.out.println("Testing Message Validation...");
        
        // Test valid message length
        String result1 = POEPART3.Message.validateMessageLength("Hello");
        assertEquals("Message ready to send.", result1);
        
        // Test message at maximum length
        String shortMessage = "A".repeat(250);
        String result2 = POEPART3.Message.validateMessageLength(shortMessage);
        assertEquals("Message ready to send.", result2);
        
        // Test message exceeding maximum length
        String longMessage = "A".repeat(251);
        String result3 = POEPART3.Message.validateMessageLength(longMessage);
        assertTrue(result3.contains("too long"), "Should indicate message is too long");
        assertTrue(result3.contains("251"), "Should show current length");
        assertTrue(result3.contains("250"), "Should show maximum allowed");
    }
    
    @Test
    public void testMessageHashGeneration() {
        System.out.println("Testing Message Hash Generation...");
        
        // Create a test message and verify hash is generated
        POEPART3.Message testMessage = new POEPART3.Message("+27831234567", "Test message");
        
        assertNotNull(testMessage.getMessageHash(), "Message hash should not be null");
        assertFalse(testMessage.getMessageHash().isEmpty(), "Message hash should not be empty");
        assertTrue(testMessage.getMessageHash().matches("[a-f0-9]+"), "Message hash should be hexadecimal");
    }
    
    @Test
    public void testMessageIdGeneration() {
        System.out.println("Testing Message ID Generation...");
        
        // Create multiple messages and verify unique IDs
        POEPART3.Message msg1 = new POEPART3.Message("+27831234567", "Message 1");
        POEPART3.Message msg2 = new POEPART3.Message("+27831234567", "Message 2");
        
        assertNotNull(msg1.getMessageId(), "Message ID should not be null");
        assertNotNull(msg2.getMessageId(), "Message ID should not be null");
        assertNotEquals(msg1.getMessageId(), msg2.getMessageId(), "Message IDs should be unique");
        assertTrue(msg1.getMessageId().startsWith("MSG"), "Message ID should start with MSG");
    }
    
    @Test
    public void testMessageArraysInitialization() {
        System.out.println("Testing Message Arrays Initialization...");
        
        // Test that arrays are properly initialized and accessible
        assertNotNull(POEPART3.Message.getSentMessages(), "Sent messages array should not be null");
        assertNotNull(POEPART3.Message.getStoredMessages(), "Stored messages array should not be null");
        assertNotNull(POEPART3.Message.getDisregardedMessages(), "Disregarded messages array should not be null");
        
        // Initially should be empty
        assertEquals(0, POEPART3.Message.getSentMessages().size(), "Sent messages should be empty initially");
        assertEquals(0, POEPART3.Message.getStoredMessages().size(), "Stored messages should be empty initially");
        assertEquals(0, POEPART3.Message.getDisregardedMessages().size(), "Disregarded messages should be empty initially");
    }
    
    @Test
    public void testJSONFileOperations() {
        System.out.println("Testing JSON File Operations...");
        
        // Test that JSON file can be created without errors
        try {
            POEPART3.Message.saveMessagesToJSON();
            // If no exception is thrown, the test passes
            assertTrue(true, "JSON save operation should complete without errors");
        } catch (Exception e) {
            fail("JSON file operations should not throw exceptions: " + e.getMessage());
        }
    }
    
    @Test
    public void testMessageCounters() {
        System.out.println("Testing Message Counters...");
        
        // Test that message counters work correctly
        assertEquals(0, POEPART3.Message.returnTotalMessages(), "Total messages should be 0 initially");
        assertEquals(0, POEPART3.Message.returnTotalStoredMessages(), "Total stored messages should be 0 initially");
        
        // Verify counters are non-negative
        assertTrue(POEPART3.Message.returnTotalMessages() >= 0, "Counters should be non-negative");
        assertTrue(POEPART3.Message.returnTotalStoredMessages() >= 0, "Counters should be non-negative");
    }
    
    @Test
    public void testPhoneNumberValidation() {
        System.out.println("Testing Phone Number Validation...");
        
        // Test South African phone number validation
        assertTrue(POEPART3.checkSouthAfricaCellPhoneNumber("+27831234567"), "Valid international format should pass");
        assertTrue(POEPART3.checkSouthAfricaCellPhoneNumber("0831234567"), "Valid local format should pass");
        assertFalse(POEPART3.checkSouthAfricaCellPhoneNumber("1234567890"), "Invalid format should fail");
        assertFalse(POEPART3.checkSouthAfricaCellPhoneNumber("+278312345"), "Too short should fail");
        assertFalse(POEPART3.checkSouthAfricaCellPhoneNumber("+278312345678"), "Too long should fail");
        assertFalse(POEPART3.checkSouthAfricaCellPhoneNumber("+447812345678"), "Wrong prefix should fail");
    }
    
    @Test
    public void testPasswordHashing() {
        System.out.println("Testing Password Hashing...");
        
        // Test that password hashing works consistently
        String password = "testPassword123";
        String hash1 = POEPART3.hashPassword(password);
        String hash2 = POEPART3.hashPassword(password);
        
        assertNotNull(hash1, "Hash should not be null");
        assertFalse(hash1.isEmpty(), "Hash should not be empty");
        assertEquals(hash1, hash2, "Same password should produce same hash");
        assertEquals(64, hash1.length(), "Hash should be 64 characters (SHA-256)");
        assertTrue(hash1.matches("[a-f0-9]+"), "Hash should be hexadecimal");
        
        // Test different passwords produce different hashes
        String differentPassword = "differentPassword123";
        String differentHash = POEPART3.hashPassword(differentPassword);
        assertNotEquals(hash1, differentHash, "Different passwords should produce different hashes");
    }
    
    @Test
    public void testMessageSending() {
        System.out.println("Testing Message Sending...");
        
        // Create a test user context
        POEPART3.User testUser = new POEPART3.User("Test", "User", "testuser", "password", "+27831234567");
        POEPART3.currentUser = testUser;
        
        // Create and send a message
        POEPART3.Message testMessage = new POEPART3.Message("+27837654321", "Test message content");
        String result = testMessage.sentMessage(0); // 0 = Send message
        
        assertTrue(result.contains("sent successfully"), "Should indicate successful send");
        assertEquals(1, POEPART3.Message.getSentMessages().size(), "Sent messages array should have 1 message");
        assertEquals(1, POEPART3.Message.returnTotalMessages(), "Total messages counter should be 1");
        
        // Clean up
        POEPART3.currentUser = null;
    }
    
    @Test
    public void testMessageStorage() {
        System.out.println("Testing Message Storage...");
        
        // Create a test user context
        POEPART3.User testUser = new POEPART3.User("Test", "User", "testuser", "password", "+27831234567");
        POEPART3.currentUser = testUser;
        
        // Create and store a message
        POEPART3.Message testMessage = new POEPART3.Message("+27837654321", "Test stored message");
        String result = testMessage.sentMessage(2); // 2 = Store message
        
        assertTrue(result.contains("stored successfully"), "Should indicate successful storage");
        assertEquals(1, POEPART3.Message.getStoredMessages().size(), "Stored messages array should have 1 message");
        assertEquals(1, POEPART3.Message.returnTotalStoredMessages(), "Total stored messages counter should be 1");
        
        // Clean up
        POEPART3.currentUser = null;
    }
    
    @Test
    public void testGetAllMessages() {
        System.out.println("Testing GetAllMessages...");
        
        // Add messages to different arrays
        POEPART3.Message sentMsg = new POEPART3.Message("+27831111111", "Sent message");
        POEPART3.Message storedMsg = new POEPART3.Message("+27832222222", "Stored message");
        POEPART3.Message disregardedMsg = new POEPART3.Message("+27833333333", "Disregarded message");
        
        POEPART3.Message.getSentMessages().add(sentMsg);
        POEPART3.Message.getStoredMessages().add(storedMsg);
        POEPART3.Message.getDisregardedMessages().add(disregardedMsg);
        
        // Test getAllMessages method
        List<POEPART3.Message> allMessages = POEPART3.Message.getAllMessages();
        
        assertNotNull(allMessages, "All messages list should not be null");
        assertEquals(3, allMessages.size(), "Should contain all 3 messages");
        assertTrue(allMessages.contains(sentMsg), "Should contain sent message");
        assertTrue(allMessages.contains(storedMsg), "Should contain stored message");
        assertTrue(allMessages.contains(disregardedMsg), "Should contain disregarded message");
    }
}